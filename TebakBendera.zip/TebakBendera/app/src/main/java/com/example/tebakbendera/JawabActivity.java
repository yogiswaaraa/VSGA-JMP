package com.example.tebakbendera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class JawabActivity extends AppCompatActivity {
    ImageView imageView_tebak;
    EditText editText_jawabb;
    Button button_cek;

    String jawaban;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jawab);

        imageView_tebak = (ImageView) findViewById(R.id.imageView_tebak);
        editText_jawabb = (EditText) findViewById(R.id.editText_jawab);
        button_cek = (Button) findViewById(R.id.buttonCek);

        Intent cek = getIntent();
        String nama_icon = cek.getStringExtra("nama_icon");

        if (nama_icon.equals("belgium")) {
            imageView_tebak.setImageResource(R.drawable.bendera_belgium);
            jawaban = "belgium";
        } else if (nama_icon.equals("brazil")) {
            imageView_tebak.setImageResource(R.drawable.bendera_brazil);
            jawaban = "brazil";
        } else if (nama_icon.equals("indonesia")) {
            imageView_tebak.setImageResource(R.drawable.bendera_indonesia);
            jawaban = "indonesia";
        } else if (nama_icon.equals("jepang")) {
            imageView_tebak.setImageResource(R.drawable.bendera_jepang);
            jawaban = "jepang";
        } else if (nama_icon.equals("rusia")) {
            imageView_tebak.setImageResource(R.drawable.bendera_rusia);
            jawaban = "rusia";
        } else {
            imageView_tebak.setImageResource(R.drawable.bendera_ukraina);
            jawaban = "ukraina";
        }

        onClickButton();
    }
    private void onClickButton(){
        button_cek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editText_jawabb.getText().toString().equals(jawaban)){
                    Toast.makeText(JawabActivity.this, "jawaban benar!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(JawabActivity.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(JawabActivity.this, "jawaban salah!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}