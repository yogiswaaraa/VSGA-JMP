package com.example.tebakbendera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView imageView_belgium, imageView_brazil, imageView_indonesia,
            imageView_jepang, imageView_rusia, imageView_ukraina;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setImage();
        setOnClick();
    }

    private void setImage() {
        imageView_belgium= (ImageView)findViewById(R.id.imageView_belgium);
        imageView_brazil= (ImageView)findViewById(R.id.imageView_brazil);
        imageView_indonesia= (ImageView)findViewById(R.id.imageView_indonesia);
        imageView_jepang= (ImageView)findViewById(R.id.imageView_jepang);
        imageView_rusia= (ImageView)findViewById(R.id.imageView_rusia);
        imageView_ukraina= (ImageView)findViewById(R.id.imageView_ukraina);
    }

    private void setOnClick(){
        imageView_belgium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(MainActivity.this,JawabActivity.class);
                d.putExtra("nama_icon", "belgium");
                startActivity(d);
            }
        });

        imageView_brazil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(MainActivity.this,JawabActivity.class);
                c.putExtra("nama_icon", "brazil");
                startActivity(c);
            }
        });

        imageView_indonesia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, JawabActivity.class);
                a.putExtra("nama_icon","indonesia");
                startActivity(a);
            }
        });

        imageView_jepang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent al = new Intent(MainActivity.this,JawabActivity.class);
                al.putExtra("nama_icon","jepang");
                startActivity(al);
            }
        });

        imageView_rusia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent al = new Intent(MainActivity.this,JawabActivity.class);
                al.putExtra("nama_icon","rusia");
                startActivity(al);
            }
        });

        imageView_ukraina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent al = new Intent(MainActivity.this,JawabActivity.class);
                al.putExtra("nama_icon","ukraina");
                startActivity(al);
            }
        });

    }

}